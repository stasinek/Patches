copy dstring.h "C:\Program Files (x86)\Borland\CBuilder6\Include\Vcl"
copy shlobj.hpp "C:\Program Files (x86)\Borland\CBuilder6\Include\Vcl"
copy winuser.h "C:\Program Files (x86)\Borland\CBuilder6\Include"