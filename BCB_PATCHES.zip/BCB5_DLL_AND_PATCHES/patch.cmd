copy dstring.h "C:\Program Files\Borland\CBuilder6\Include\Vcl"
copy shlobj.hpp "C:\Program Files\Borland\CBuilder6\Include\Vcl"
copy winuser.h "C:\Program Files\Borland\CBuilder6\Include"